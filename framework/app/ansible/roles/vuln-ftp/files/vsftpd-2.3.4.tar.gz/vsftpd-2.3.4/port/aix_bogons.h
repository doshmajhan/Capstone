#ifndef VSF_AIX_BOGONS_H
#define VSF_AIX_BOGONS_H

/* Need dirfd() */
#include "dirfd_extras.h"

#endif /* VSF_AIX_BOGONS_H */

